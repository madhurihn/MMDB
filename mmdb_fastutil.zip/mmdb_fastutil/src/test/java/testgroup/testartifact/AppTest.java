package testgroup.testartifact;

public class AppTest {

}
