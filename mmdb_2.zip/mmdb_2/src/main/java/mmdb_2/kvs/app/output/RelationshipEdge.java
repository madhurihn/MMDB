package mmdb_2.kvs.app.output;

public class RelationshipEdge {
	String StartId;
	String EndId;
	
	public String getStartId() {
		return StartId;
	}
	public void setStartId(String startId) {
		this.StartId = startId;
	}
	public String getEndId() {
		return EndId;
	}
	public void setEndId(String endId) {
		this.EndId = endId;
	}
}
