package mmdb_2.kvs.app.output;

import java.util.List;


public class IncomingEdges {
private List<String> IncomingEdges;
	
	public void setIncomingEdges(){
		List<String> IncomingEdges;
	}
	public List<String> getIncomingEdges()
	{
		return IncomingEdges;
	}
	public void setNode(IncomingEdges n) {
		this.IncomingEdges = IncomingEdges;
	}
}