package mmdb_2.kvs.app.output;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import mmdb_2.kvs.app.output.pair;

public class pairs {
	
	List<pair> pairs;

	public pairs (List<pair> pairs) {
		this.pairs=pairs;
	}
	
	@JsonProperty
	public List<pair> getPairs() {
		return pairs;
	}

	public void setPairs(List<pair> pairs) {
		this.pairs = pairs;
	}

}