package mmdb_2.kvs.app.output;

import java.util.List;

public class OutgoingEdges {
private List<String> OutgoingEdges;
	
	public void setOutgoingEdges(){
		List<String> OutgoingEdges;
	}
	public List<String> getOutgoingEdges()
	{
		return OutgoingEdges;
	}
	public void setNode(OutgoingEdges n) {
		this.OutgoingEdges = OutgoingEdges;
	}

}