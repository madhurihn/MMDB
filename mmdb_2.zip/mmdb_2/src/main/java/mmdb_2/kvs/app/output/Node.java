package mmdb_2.kvs.app.output;


import java.util.HashMap;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Node {
	private String profileID;
	private HashMap<String, String> profile;
	//private String profiles;
	
	public void Node () {
		profile = new HashMap<>();
	}
	@JsonProperty
	public void setProfileID(String profileID) {
		this.profileID= profileID;
	}
	public String getProfileID() {
		return profileID;
	}
	public void setProfile(HashMap<String, String> profile) {
		this.profile=profile;
	 
	}
	public HashMap<String, String> getProfile(){
		return profile;
	}
//	public void setProfiles(String profiles) {
//		this.profiles=profiles;
//	}
//	public String getProfiles() {
//		return profiles;
//	}
}