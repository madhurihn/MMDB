package mmdb_2.kvs.app.output;

import java.util.ArrayList;
import java.util.List;

public class Nodes {
	private List<Node> nodes;
	
	public void Nodes() {
		nodes= new ArrayList<>();
	}
	
	public List<Node> getNode()
	{
		return nodes;
	}
	
	public void setNode(Node n) {
		if (this.nodes == null) {
			nodes= new ArrayList<>();
		}
		this.nodes.add(n);
	}
}