package mmdb_2.kvs.app.output;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FineGrainedPair {

}
