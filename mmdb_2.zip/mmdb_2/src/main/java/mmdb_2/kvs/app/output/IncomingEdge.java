package mmdb_2.kvs.app.output;

public class IncomingEdge {
	
	String IEdgeId;
	
	String getEdgeId() {
		return IEdgeId;
	}

	public void setEdgeId(String iedgeId) {
		this.IEdgeId = iedgeId;
	}
}