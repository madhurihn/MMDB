package mmdb_2.kvs.app.resources;


	//package mmdb.kvs.app.resources;
	import java.io.InputStreamReader;
	import java.io.Reader;

import org.apache.commons.csv.CSVFormat;
	import org.apache.commons.csv.CSVRecord;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
	import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
	import java.util.HashSet;
	import java.util.Iterator;
	import java.util.List;
	import java.util.Map;
	import java.util.Vector;
	import java.util.concurrent.ConcurrentNavigableMap;
	import java.util.Map.Entry;
	import java.util.Set;
	//import java.util.concurrent.ConcurrentNavigableMap;
	//import java.util.concurrent.ConcurrentSkipListMap;
	//import com.koloboke.collect.map.*;
	//import com.koloboke.collect.map.hash.*; 
	//import com.koloboke.collect.set.hash.HashObjSets;
	//import java.util.concurrent.ConcurrentSkipListMap;
	import java.util.StringTokenizer;

	import com.carrotsearch.hppc.*;
	import com.carrotsearch.hppc.cursors.*;
	//import com.carrotsearch.hppc.cursors.ObjectCursor;
	//import com.carrotsearch.hppc.cursors.ObjectObjectCursor;

	import javax.ws.rs.Consumes;
	import javax.ws.rs.DELETE;
	import javax.ws.rs.GET;
	import javax.ws.rs.POST;
	import javax.ws.rs.PUT;
	import javax.ws.rs.Path;
	import javax.ws.rs.PathParam;
	import javax.ws.rs.Produces;
	import javax.ws.rs.QueryParam;
	import javax.ws.rs.core.MediaType;
	import javax.ws.rs.core.Response;
	import javax.ws.rs.core.Response.Status;

	import org.apache.commons.csv.CSVFormat;
	import org.apache.commons.csv.CSVParser;
	import org.apache.commons.csv.CSVRecord;

	import com.codahale.metrics.annotation.Timed;
	import com.wordnik.swagger.annotations.Api;
	import com.wordnik.swagger.annotations.ApiOperation;
	import com.wordnik.swagger.annotations.ApiResponses;

import gnu.trove.map.hash.THashMap;
import mmdb_2.kvs.app.output.FineGrainedPair;
	import mmdb_2.kvs.app.output.FineGrainedPairs;
import mmdb_2.kvs.app.output.Nodes;
import mmdb_2.kvs.app.output.Node;

	import com.wordnik.swagger.annotations.ApiResponse;

	import scala.collection.immutable.Map.Map2;

	import java.io.BufferedReader;
	//import java.io.Console;
	//import java.io.FileNotFoundException;
	import java.io.FileReader;
	import java.io.IOException;
	import java.io.Reader;
	import java.lang.Character.Subset;
	import java.nio.file.Files;
	import java.nio.file.Paths;
	import org.apache.commons.csv.CSVPrinter;
	import java.io.FileInputStream;
	import java.io.FileNotFoundException;
	import java.io.IOException;
	import java.io.InputStreamReader;
	import java.io.Reader;
	import org.apache.commons.csv.CSVFormat;
	import org.apache.commons.csv.CSVRecord;

	@Path("pairs")
	@Api(value = "pairs", description = "Pairs API")
	@Produces(MediaType.APPLICATION_JSON)
	public class pairsResource<node> {
//		public static ConcurrentNavigableMap<String,Map<String, String>> map;
//		private static List<String> fields;
//		private static final String tableName="User";
		//public static ObjectObjectAssociativeContainer<String, HashMap<String, Object>> map ;
		public static THashMap<String,Map<String, Object>> map;
		private static List<String> fields;
		private static final String tableName="User";
		HashMap<String, ArrayList<String>> in = new HashMap<String, ArrayList<String>>();
	    HashMap<String, ArrayList<String>> out = new HashMap<String, ArrayList<String>>();
	    HashMap<String, String> profiles = new HashMap<String, String>();
	    

	    public pairsResource() throws IOException {
	    
	    	
	    	//Reader reader = null;
	    	
	    		
	    		this.map = new THashMap<String, Map<String, Object>>();
	    		
	    		
	            //Complete Dataset
	    		String csvForProfiles = "node-pokec-profiles.csv";
	            String csvForRelationships = "results-relationships.csv";
	            //50s
	            //String csvForProfiles = "/home/raksha/Desktop/mmdb/node-pokec-profiles.csv";
	            //String csvForRelationships = "/home/raksha/Desktop/mmdb/results-relationships.csv";
	            
	            BufferedReader br = null;
	            String splitBy = ",";
	            BufferedReader inp = new BufferedReader(new FileReader(csvForProfiles));
	            //String line1 = inp.read();
	            String line = inp.readLine();
	            String line0 = Files.readAllLines(Paths.get(csvForProfiles)).get(1);
	            //ArrayList<String> profileIDarray = new ArrayList<String>();
	            
	            //HashMap<String, String> p = new HashMap<String, String>();
	            
	            String profileIDs[] = null;
	        	HashMap<String, Object> tempMap = new HashMap<String, Object>();
	            tempMap.put("incoming", new HashSet<String>());
	          	tempMap.put("outgoing", new HashSet<String>());

	            while ((line = inp.readLine()) != null) {
	            	
	            	profileIDs = line.split(",");
	            	tempMap.put("properties", line);
	            map.put(profileIDs[0],new HashMap(tempMap));
	           
	            }
	            inp.close();
	            inp = new BufferedReader(new FileReader(csvForRelationships));
	            Set<String> stringSet = null;
	            while ((line = inp.readLine()) != null) {
	            	//System.out.println("Here we read from the edges...");
	            	profileIDs = line.replace("\"", "").split(",");
	            	if (profileIDs.length>=2) {
	            		System.out.println("Source: "+profileIDs[0]+", Target:"+profileIDs[1]);
	            	if (map.containsKey(profileIDs[0]) && map.containsKey(profileIDs[1])) {
	            		//Insert as incoming (we insert in profileIDs[1])
	            		tempMap = (HashMap<String, Object>) map.get(profileIDs[1]);
	                stringSet = (Set<String>)tempMap.get("incoming");
	            		stringSet.add(profileIDs[0]);
	            		tempMap.put("incoming", new HashSet(stringSet));
	            		map.put(profileIDs[1], new HashMap(tempMap));
	            		
	            		//Insert as outgoing (we insert in profileIDs[0])
	            		tempMap = (HashMap<String, Object>) map.get(profileIDs[0]);
	            		stringSet = (Set<String>)tempMap.get("outgoing");
	            		stringSet.add(profileIDs[1]);
	            		tempMap.put("outgoing", new HashSet(stringSet));
	            		map.put(profileIDs[0], new HashMap(tempMap));
	            	}
	            	else {
	            		System.out.println("Hey, a key was not contained.");
	            	}
	            	}
	            	else {
	            		System.out.println("Hey, me not like that line.");
	            	}
	            }
	            
	            map.entrySet().stream().forEach(it->{
	            	System.out.println("***********");
	            	System.out.println("Key: "+it.getKey());
	            	Map<String, Object> someMap = it.getValue();
	            	System.out.println("Properties: "+((String)someMap.get("properties")).substring(0, 20));
	            	Set<String> incomingEdges = (Set<String>)someMap.get("incoming");
	            	System.out.println("Incoming Edges...");
	            	incomingEdges.forEach(it2->{
	            		System.out.println(it2);
	            	});
	            	incomingEdges = (Set<String>)someMap.get("outgoing");
	            	System.out.println("Outgoing Edges...");
	            	incomingEdges.forEach(it2->{
	            		System.out.println(it2);
	            	});
	            });
	         }
	                 
	  //get neighbors based on the given key 
        @GET
        @Path("{key}/neighbors")
        @Produces(MediaType.APPLICATION_JSON)
    	@ApiOperation(value = "Get neighbors based on key",
    			notes = "Description here.",
    			response =String.class, responseContainer="list")
        @Timed
        public Response getNeighbors(@PathParam(value="key") String key) {
        		Set<String> nodes = new HashSet<String>();
        		long startTime = System.nanoTime();    
        		if (map.containsKey(key)) {
        			System.out.println("Key existed...");
        			nodes = (Set<String>) map.get(key).get("incoming");
        			nodes.addAll((Set<String>) map.get(key).get("outgoing"));
//        			nodes.forEach(n->{
//        				System.out.println(n);
//        			});
	    		}
        		long estimatedTime = System.nanoTime() - startTime;
        		System.out.println("Time taken: "+estimatedTime);
        		return Response.ok(nodes).build();         
        	}
	    
  	  //get neighbors based on the given key 
        @GET
        @Path("{key}/neighbors2")
        @Produces(MediaType.APPLICATION_JSON)
    	@ApiOperation(value = "Get neighbors based on key",
    			notes = "Description here.",
    			response =String.class, responseContainer="list")
        @Timed
        public Response getNeighbors2(@PathParam(value="key") String key) {
        		Set<String> nodes = new HashSet<String>();
        		Set<String> state = new HashSet<String>();
        		state.add(key);
        		if (map.containsKey(key)) {
        			System.out.println("Key existed...");
        			nodes = (Set<String>) map.get(key).get("incoming");
        			nodes.addAll((Set<String>) map.get(key).get("outgoing"));
        			Iterator<String> it = nodes.iterator();
        			Set<String> newNodes = new HashSet<>();
        			while (it.hasNext()) {
        				String visit = it.next();
        				if (visit!=null && map.containsKey(visit) && !visit.equals(key)) {
        					newNodes.addAll((Set<String>) map.get(visit).get("incoming"));
                			newNodes.addAll((Set<String>) map.get(visit).get("outgoing"));
        				}
        			}
        			nodes.addAll(newNodes);
//        			nodes.forEach(n->{
//        				System.out.println(n);
//        			});
	    		}
        		List<String> resp = new ArrayList(nodes);
        		Collections.sort(resp);
        		return Response.ok(resp).build();         
        	}

    	  //get neighbors based on the given key 
        @GET
        @Path("{key}/neighbors2Data")
        @Produces(MediaType.APPLICATION_JSON)
    	@ApiOperation(value = "Get neighbors data based on the given key",
    			notes = "Description here.",
    			response =Nodes.class)
        @Timed
        public Response getNeighbors2Data(@PathParam(value="key") String key) {
        		Nodes nodes = new Nodes();
        		if (map.containsKey(key)) {
        			Node node = new Node();
        			HashMap<String, String> profile = new HashMap<String, String>();
        			node.setProfileID(key);
        			profile.put("properties", (String)map.get(key).get("properties"));
        			profile.put("incoming", StringUtils.join((Set<String>)map.get(key).get("incoming"), ","));
        			profile.put("outgoing", StringUtils.join((Set<String>)map.get(key).get("outgoing"), ","));
        			node.setProfile(profile);
        			nodes.setNode(node);
        			Set<String> firstHop = (Set<String>) map.get(key).get("incoming");
        			firstHop.addAll((Set<String>) map.get(key).get("outgoing"));
        			Iterator<String> it = firstHop.iterator();
        			Set<String> newNodes = new HashSet<>();
        			while (it.hasNext()) {
        				String visit = it.next();
        				if (visit!=null && map.containsKey(visit) && !visit.equals(key)) {
        					node = new Node();
                			profile.clear();
                			node.setProfileID(visit);
                			profile.put("properties", (String)map.get(visit).get("properties"));
                			profile.put("incoming", StringUtils.join((Set<String>)map.get(visit).get("incoming"), ","));
                			profile.put("outgoing", StringUtils.join((Set<String>)map.get(visit).get("outgoing"), ","));
                			node.setProfile(profile);
                			nodes.setNode(node);
        					newNodes.addAll((Set<String>) map.get(visit).get("incoming"));
                			newNodes.addAll((Set<String>) map.get(visit).get("outgoing"));
        				}
        			}
        			it = newNodes.iterator();
        			while (it.hasNext()) {
        				String visit = it.next();
        				if (visit!=null && map.containsKey(visit) && !firstHop.contains(visit) && !visit.equals(key)) {
        					node = new Node();
                			profile.clear();
                			node.setProfileID(visit);
                			profile.put("properties", (String)map.get(visit).get("properties"));
                			profile.put("incoming", StringUtils.join((Set<String>)map.get(visit).get("incoming"), ","));
                			profile.put("outgoing", StringUtils.join((Set<String>)map.get(visit).get("outgoing"), ","));
                			node.setProfile(profile);
                			nodes.setNode(node);
        				}
        			}
        			
        			//nodes.addAll(newNodes);
//        			nodes.forEach(n->{
//        				System.out.println(n);
//        			});
	    		}
        		nodes.getNode().sort(new Comparator<Node>() {
        		    public int compare(Node a, Node b) {
        		        return a.getProfileID().compareTo(b.getProfileID()); //assuming a.second is not null
        		    }
        		});
        		return Response.ok(nodes.getNode()).build();         
        	}
	    
        //get neighbors based on the given key 
        @GET
        @Path("{key}/neighbors_at_scale")
        @Produces(MediaType.APPLICATION_JSON)
    	@ApiOperation(value = "Get neighbors",
    			notes = "Description here.",
    			response =Long.class)
        @Timed
        public Response getNeighborsAtScale(@PathParam(value="key") String key) {
        		key.replaceAll("[^0-9,]", "");
        		Set<String> nodes = new HashSet<String>();
        		List<String> keys = Arrays.asList(key.split(","));
        		long startTime = System.nanoTime();  
        		keys.stream().forEach(neighbor->{
        			if (map.containsKey(neighbor)) {
            			Set<String> nodes2= (Set<String>) map.get(neighbor).get("incoming");
            			nodes2.addAll((Set<String>) map.get(neighbor).get("outgoing"));
//            			nodes.forEach(n->{
//            				System.out.println(n);
//            			});
    	    		}
        		});
        		
        		long estimatedTime = System.nanoTime() - startTime;
        		System.out.println("Time taken: "+estimatedTime);
        		return Response.ok(estimatedTime).build();         
        	}
	    
//  	  //get neighbors based on the given key 
//        @GET
//        @Path("{key}/neighbors2")
//        @Produces(MediaType.APPLICATION_JSON)
//    	@ApiOperation(value = "Get neighbors",
//    			notes = "Description here.",
//    			response =String.class, responseContainer="list")
//        @Timed
//        public Response getNeighbors2(@PathParam(value="key") String key) {
//        		Set<String> nodes = new HashSet<String>();
//        		Set<String> state = new HashSet<String>();
//        		state.add(key);
//        		if (map.containsKey(key)) {
//        			System.out.println("Key existed...");
//        			nodes = (Set<String>) map.get(key).get("incoming");
//        			nodes.addAll((Set<String>) map.get(key).get("outgoing"));
//        			Iterator<String> it = nodes.iterator();
//        			Set<String> newNodes = new HashSet<>();
//        			while (it.hasNext()) {
//        				String visit = it.next();
//        				if (visit!=null && map.containsKey(visit) && !visit.equals(key)) {
//        					newNodes.addAll((Set<String>) map.get(visit).get("incoming"));
//                			newNodes.addAll((Set<String>) map.get(visit).get("outgoing"));
//        				}
//        			}
//        			nodes.addAll(newNodes);
////        			nodes.forEach(n->{
////        				System.out.println(n);
////        			});
//	    		}
//        		List<String> resp = new ArrayList(nodes);
//        		Collections.sort(resp);
//        		return Response.ok(resp).build();         
//        	}
//
//    	  //get neighbors based on the given key 
//        @GET
//        @Path("{key}/neighbors2Data")
//        @Produces(MediaType.APPLICATION_JSON)
//    	@ApiOperation(value = "Get neighbors",
//    			notes = "Description here.",
//    			response =Nodes.class)
//        @Timed
//        public Response getNeighbors2Data(@PathParam(value="key") String key) {
//        		Nodes nodes = new Nodes();
//        		if (map.containsKey(key)) {
//        			Node node = new Node();
//        			HashMap<String, String> profile = new HashMap<String, String>();
//        			node.setProfileID(key);
//        			profile.put("properties", (String)map.get(key).get("properties"));
//        			profile.put("incoming", StringUtils.join((Set<String>)map.get(key).get("incoming"), ","));
//        			profile.put("outgoing", StringUtils.join((Set<String>)map.get(key).get("outgoing"), ","));
//        			node.setProfile(profile);
//        			nodes.setNode(node);
//        			Set<String> firstHop = (Set<String>) map.get(key).get("incoming");
//        			firstHop.addAll((Set<String>) map.get(key).get("outgoing"));
//        			Iterator<String> it = firstHop.iterator();
//        			Set<String> newNodes = new HashSet<>();
//        			while (it.hasNext()) {
//        				String visit = it.next();
//        				if (visit!=null && map.containsKey(visit) && !visit.equals(key)) {
//        					node = new Node();
//                			profile.clear();
//                			node.setProfileID(visit);
//                			profile.put("properties", (String)map.get(visit).get("properties"));
//                			profile.put("incoming", StringUtils.join((Set<String>)map.get(visit).get("incoming"), ","));
//                			profile.put("outgoing", StringUtils.join((Set<String>)map.get(visit).get("outgoing"), ","));
//                			node.setProfile(profile);
//                			nodes.setNode(node);
//        					newNodes.addAll((Set<String>) map.get(visit).get("incoming"));
//                			newNodes.addAll((Set<String>) map.get(visit).get("outgoing"));
//        				}
//        			}
//        			it = newNodes.iterator();
//        			while (it.hasNext()) {
//        				String visit = it.next();
//        				if (visit!=null && map.containsKey(visit) && !firstHop.contains(visit) && !visit.equals(key)) {
//        					node = new Node();
//                			profile.clear();
//                			node.setProfileID(visit);
//                			profile.put("properties", (String)map.get(visit).get("properties"));
//                			profile.put("incoming", StringUtils.join((Set<String>)map.get(visit).get("incoming"), ","));
//                			profile.put("outgoing", StringUtils.join((Set<String>)map.get(visit).get("outgoing"), ","));
//                			node.setProfile(profile);
//                			nodes.setNode(node);
//        				}
//        			}
//        			
//        			//nodes.addAll(newNodes);
////        			nodes.forEach(n->{
////        				System.out.println(n);
////        			});
//	    		}
//        		nodes.getNode().sort(new Comparator<Node>() {
//        		    public int compare(Node a, Node b) {
//        		        return a.getProfileID().compareTo(b.getProfileID()); //assuming a.second is not null
//        		    }
//        		});
//        		return Response.ok(nodes.getNode()).build();         
//        	}
	    }

	 

	//scan operator

		