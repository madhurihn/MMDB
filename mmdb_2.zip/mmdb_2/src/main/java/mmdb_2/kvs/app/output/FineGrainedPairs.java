package mmdb_2.kvs.app.output;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class FineGrainedPairs {
	

}