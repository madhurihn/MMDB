package mmdb_2.kvs.app.output;

public class OutgoingEdge {
	
	String OEdgeId;
	
	String getEdgeId() {
		return OEdgeId;
	}

	public void setEdgeId(String oedgeId) {
		this.OEdgeId = oedgeId;
	}
}