package mmdb_2.kvs.app.output;

import java.util.List;

public class RelationshipEdges {
	private List<String> RelationshipEdges;
	
	public void setRelationshipEdges(){
		List<String> RelationshipEdges;
	}
	public List<String> getRelationshipEdges()
	{
		return RelationshipEdges;
	}
	public void setNode(IncomingEdges n) {
		this.RelationshipEdges = RelationshipEdges;
	}	

}
